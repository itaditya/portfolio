# typing.js
Typing.js is a typewriter animation written with vanilla JavaScript.

## How to Use

## Functionalities

#### Customizations
###### Typing Speed and Wait Times
###### Text Cursor Character

#### Skip Function
###### Toggle Skip Function
###### Customize Keypress Trigger

## Limitations

## Changelogs
